#include "mapreduce.h"

Q workQue;
int toRead = NUMFILES;
omp_lock_t qLock;
omp_lock_t toReadLock;

HTQ** hashTables;

int abc = 0;


char* readLine(FILE* fd) {
	char* buf = malloc(LINELEN);
	return fgets ( buf, LINELEN, fd );
}

void readFile(char* fileName) {
	char* line;
	FILE* fd = fopen(fileName, "r");
	if (fd == NULL) {
		printf("Cant open FILE: %s.\n",fileName);
		return;
	}
	//printf("%s\n",fileName);
	while ((line = readLine(fd)) != NULL) {
		putWork (line);
	}
	omp_set_lock(&toReadLock);
	toRead--;
	omp_unset_lock(&toReadLock);
	fclose(fd);
}

void putWork(char* line) {
	Node* node = malloc (sizeof (Node));
	omp_set_lock(&qLock);
	node->next = workQue.head;
	node->line = line;
	if (workQue.head == NULL) {
		workQue.tail = node;
	}
	workQue.head = node;
	omp_unset_lock(&qLock);
}

Node* getWork() {
	Node* node;
	omp_set_lock(&qLock);
	if (workQue.head == NULL) {
		omp_unset_lock(&qLock);
		return NULL;
	}
	node = workQue.head;
	if (workQue.head == workQue.tail) {
		workQue.head = workQue.tail = NULL;
	}
	else {
		workQue.head = node->next;
	}
	omp_unset_lock(&qLock);
	return node;
}

void mapper() {
	Node* lineNode;
	char* line;
	char** words;
	int i = 0;
	unsigned int hashVal;
	int tid = omp_get_thread_num();

	while ((lineNode = getWork()) != NULL || toRead > 0) {
		if (lineNode == NULL)
			continue;
		line = lineNode->line;
		words = lineToWords(line);
		i = 0;
		abc++;
		while (words[i]) {
			hashVal = hash(words[i]);
			addHTNodesToQ( &(hashTables[tid][hashVal]), words[i] );
			i++;
		}
	}
}

void addHTNodesToQ (HTQ* htque, char* str) {
	HTNode* htnode;
	if ( (htnode = findNodeInQ(htque, str)) != NULL ) {
		htnode->occur++;	
		return;
	}
	htnode = malloc(sizeof(HTNode));
	htnode->word = str;
	htnode->occur = 1;
	htnode->next = htque->head;
	if (htque->head == NULL) {
		htque->tail = htnode;
	}
	htque->head = htnode;
	return;
}

void reduceHTNodeQ (HTNode* NodePtr, int idx) {
	HTNode* currNodePtr;
	HTQ* htque = &hashTables[0][idx];
	char* str = NodePtr->word;
	HTNode* htnode;
	if ( (htnode = findNodeInQ(htque, str)) != NULL ) {
		htnode->occur += NodePtr->occur;	
		return;
	}
	htnode = NodePtr;
	htnode->next = htque->head;
	if (htque->head == NULL) {
		htque->tail = htnode;
	}
	htque->head = htnode;
	return;
}

HTNode* findNodeInQ (HTQ* htque, char* str) {
	HTNode* nodePtr = htque->head;
	while ( nodePtr ) {
		if ( strcmp(nodePtr->word, str) == 0 ) {
			return nodePtr;
		}
		nodePtr = nodePtr->next;
	}
	return NULL;
}

void reducer(int idx) {
	int i;
	HTNode* NodePtr;
	HTNode* currNodePtr;


	for (i=1; i<NUM_THREADS;i++) {
		NodePtr = hashTables[i][idx].head;
		while ( NodePtr ) {
			currNodePtr = NodePtr;
			NodePtr = NodePtr->next;
			reduceHTNodeQ (currNodePtr, idx);
		}
	}
}
void writer(int i, int serPar) { 
	FILE* fd;
	int j;
	int max;
	char filename[20];
	HTNode* nodePtr;
	sprintf(filename, "result_%d_%d.txt", serPar, i);
	fd = fopen (filename, "w");
	j = i*(MAX_HASH_ENTRIES/NUM_THREADS);
	max = (i==NUM_THREADS-1) ? MAX_HASH_ENTRIES : (j + MAX_HASH_ENTRIES/NUM_THREADS);
	for (j; j<max; j++) {
		nodePtr = hashTables[0][j].head;
		while(nodePtr) {
			fprintf(fd, "%-20s%d\n", nodePtr->word, nodePtr->occur);
			nodePtr = nodePtr->next;
		}
	}
	fclose(fd);
}


void parallelExec() {
	int i, j;
	omp_set_nested(1);
#pragma omp parallel sections
	{
#pragma omp section
		{
			//printf("Section READERS threadid:%d\n", omp_get_thread_num());
#pragma omp parallel for num_threads(NUM_THREADS)
			for (i=0; i< NUMFILES; i++) {
				//printf("READER: tid:%d\n",omp_get_thread_num());
				readFile(files[i]);
			}
		}

#pragma omp section
		{
			//printf("Section MAPPERS threadid:%d\n", omp_get_thread_num());
#pragma omp parallel num_threads(NUM_THREADS)
			{
				//printf("MAPPER: mytid is: %d\n",omp_get_thread_num());
				mapper();
			}
		}
	}

#pragma omp parallel for num_threads(NUM_THREADS)
	for (i=0; i<MAX_HASH_ENTRIES; i++) {
		reducer(i);
	}

#pragma omp parallel for num_threads(NUM_THREADS)
	for (i=0; i<NUM_THREADS; i++) {
		writer(i, 0);
	}
}


void serialExec() {
	int i;
	for (i=0; i< NUMFILES; i++) {
		readFile(files[i]);
	}
	mapper();
	for (i=0; i<NUM_THREADS; i++) {
		writer(i, 1);
	}
}


int main(int argc, char* argv[]) {
	int i = 0;
	int count = 0;
	FILE *fd;
	workQue.head = NULL;
	workQue.tail = NULL;
	hashTables = malloc(sizeof(HTQ*) * NUM_THREADS);

	for (i=0; i<NUM_THREADS; i++) {
		hashTables[i] = calloc(MAX_HASH_ENTRIES, sizeof(HTQ));
	}

	omp_init_lock( &qLock );
	omp_init_lock(&toReadLock);
	double exectime1 = -omp_get_wtime();
	parallelExec();
	exectime1 += omp_get_wtime();


	workQue.head = NULL;
	workQue.tail = NULL;
	hashTables = malloc(sizeof(HTQ*));

	hashTables[0] = calloc(MAX_HASH_ENTRIES, sizeof(HTQ));


	printf("moving to sequential........\n");
	double exectime2 = -omp_get_wtime();
	serialExec();
	exectime2 += omp_get_wtime();

	printf("Parallel Time: %f, Sequential Time: %f, Speedup: %f\n", exectime1, exectime2, exectime2/exectime1);


	return 0;

}
